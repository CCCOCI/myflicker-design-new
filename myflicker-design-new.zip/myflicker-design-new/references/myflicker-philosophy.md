# MyFlicker 设计哲学

> 本文件是 `myflicker-design` 资产包的判断依据。做任何新界面设计或视觉走查前必须加载。所有具体数值以 `myflicker-design-model.yaml` 为唯一真源。

## 1. DESIGN PHILOSOPHY

MyFlicker is a quiet workbench for AI work, not a showroom. Its brand colour is near-black `#242323` - a colour that cannot be used decoratively, only decisively. The whole product runs at a 13px/20px baseline, denser than most consumer software and deliberately closer to an IDE than to a marketing site, because the user is here to work through long agent sessions, not to be impressed.

The lineage is Swiss information design filtered through the modern developer tool: hairline rules, cool-neutral greys, generous outer margins around dense inner content. The primary tension is **density versus air** - rows are tight (32px), gaps between containers are wide (16px minimum, 32px between sections). Get that ratio wrong in either direction and it stops looking like MyFlicker.

Hierarchy is carried by three things only: surface depth, type weight, and one single dark call-to-action per view. Colour is a semantic signal, never a decoration. When you are tempted to add an accent, add a border instead.

---

## 2. CRAFT RULES - HOW TO COMPOSE

### Rule 1 - Step the surface ladder exactly one level at a time

| Layer | Token | Where |
|---|---|---|
| App chrome | `--bg-brand-subtle` `#F6F6F6` | shell background, sidebar |
| Page | `--bg-base-default` `#FFFFFF` | main content pane |
| Card / panel | `--bg-base-secondary` `#F5F7FA` + 1px border | cards, table headers |
| Field / inline control | `--bg-overlay-l1` | search fields, chips, toolbar buttons |
| Hover | `--bg-overlay-l2` | any hoverable row |
| Pressed / selected | `--bg-overlay-l3` | selected rows, active pills |
| Floating | `--bg-menu` + border + shadow | menu, popover, dialog |

Never place a `--bg-base-default` panel inside a `--bg-base-secondary` container - it cuts a hole through the surface. Never nest `.mf-card` inside `.mf-card`.

### Rule 2 - Two spacing dialects, never mixed

**Intra-row (4 / 6 / 8px):** icon-to-label, inline controls, button gaps, tag internals.
**Inter-container (16 / 24 / 32 / 48px):** 16 between related cards, 24 between card groups, 32 between page sections, 48 between major regions. Page padding is 32 desktop / 16 mobile.

Using an 8px gap between two cards is the single most common way to make a MyFlicker screen look wrong.

### Rule 3 - Type budget: one family, three sizes per screen

The default is `PingFang SC` at 13/20/400. A typical product screen uses exactly three type styles: `body_sm` (13/20/400) for everything, `body_sm_medium` (13/20/500) for row titles and active states, `heading_sm` (16/24/600) for section titles. Add a fourth only when the screen genuinely has a page title (`heading_lg` 20/28/600).

`Inter` appears only on large KPI display numbers. `JetBrains Mono` appears only on code, file paths, shell commands, IDs, table numerals and keyboard hints. Marketing display copy is typeset content - never mono, never tabular figures.

**There is no 16px/400 style.** 16px ships at 500 or 600 only.

### Rule 4 - One primary CTA, and it is near-black

`.mf-btn--primary` is `#242323` on white. There is exactly one per view. If two actions feel equally important, demote both to `.mf-btn--secondary` and let copy order carry the priority. Secondary and tertiary buttons change **text colour** on hover, not background - this is unusual and it is deliberate.

Brand colour is scarce: primary action, brand identity moments, small meaningful status accents. Not hover rows, not inactive borders, not tab underlines (those use `--icon-default`), not decorative fills.

### Rule 5 - Elevation is a border, not a shadow

Cards get `1px solid --border-neutral-l1` plus one surface step. Shadows exist only for things that genuinely float: menu, popover, dialog, chat composer. Focus states are a border-colour change to `--border-brand`. No glow, no ring, no coloured outline.

### Rule 6 - Status colour is a tint plus an icon, never a fill

Success `#20BD6E`, warning `#FFB641`, error `#FF3135`, info `#1380ED`. Each has three surface alpha steps (.12 / .18 / .36). An alert tints its background and colours its icon; its body copy stays `--text-default`. A table conveys status with an inline `.mf-tag`, never by tinting the row. The one exception in the whole system: a switched-on `.mf-switch` fills with the success token - that is intentional and load-bearing.

### Rule 7 - Every product screen ships with the two-layer shell. No exceptions.

This is the single most commonly violated rule.

**What counts as a "product screen":** any page that lives inside the MyFlicker application or represents a functional view — settings, conversation, list/table, card/market, dashboard, knowledge base, workbench, evaluation page, data report, any user-generated product page. When in doubt, ask: "Is this something a user would see while *using* MyFlicker?" If yes → product screen → two-layer shell required.

**What is NOT a product screen:** landing pages and marketing pages (the `previews/myflicker-landing-page.html` archetype). These are outward-facing promotional surfaces. They use `--bg-base-default` (#FFFFFF) as the page background with no grey shell wrapper — that is intentional and correct for that archetype only.

Every product screen **must** use this exact two-layer shell:

```
html, body  →  background: var(--bg-brand-subtle)  #F6F6F6   ← outer shell / chrome
main pane   →  background: var(--bg-base-default)  #FFFFFF   ← rounded white content panel
                border-radius: 12px
                margin: 8px (or 8px 8px 8px 0 when preceded by a sidebar)
```

The gray is not the "page". The gray is the **frame**. The white is the **page**. These are two distinct DOM elements with distinct backgrounds — never collapse them into one.

**Correct (settings, list, dashboard, card, knowledge base, workbench, evaluation — all product views):**
```html
<body>  <!-- background: var(--bg-brand-subtle) via html,body rule -->
  <div class="app-shell">
    <aside class="mf-aside">…</aside>          <!-- also bg-brand-subtle -->
    <main class="main-pane">…</main>           <!-- bg-base-default, border-radius 12px, margin 8px 8px 8px 0 -->
  </div>
</body>
```

**For full-width product pages without a sidebar (dashboards, single-column views):**
```html
<body>  <!-- background: var(--bg-brand-subtle) -->
  <main class="main-pane main-pane--full">…</main>   <!-- bg-base-default, border-radius 12px, margin 8px -->
</body>
```

The minimum CSS for the shell:
```css
html, body { background: var(--bg-brand-subtle); margin: 0; height: 100%; }
.app-shell { display: flex; height: 100vh; }
.main-pane {
  flex: 1; height: calc(100vh - 16px); margin: 8px 8px 8px 0;
  background: var(--bg-base-default); border-radius: 12px;
  overflow-y: auto;
}
.main-pane--full { margin: 8px; }
```

### The squint test

Squint at the screen. You should see: one dark rectangle (the CTA), a clear light-to-lighter surface stack, and text that steps in three obvious weights. If you see coloured shapes, gradients, or more than one dark rectangle, the composition has failed.

---

## 3. ANTI-PATTERNS - WHAT TO NEVER DO

1. **No new palettes.** No raw hex values, no ad-hoc `rgba()` overlays. Every colour resolves to a token in `references/myflicker-tokens.md`.
2. **No brand colour as decoration.** Not for hover rows, inactive borders, tab underlines, section dividers or decorative fills.
3. **No gradient blobs, glows, mesh fields, mascots, decorative icon clusters or abstract shapes.** MyFlicker has zero background graphics by design.
4. **No drop shadows on cards.** Border plus one surface step. Shadows only for menu / popover / dialog / composer.
5. **No nested bordered or filled containers.** One surface, internal dividers and spacing.
6. **No 4 / 6 / 8px gaps between containers.** Those are intra-row values.
7. **No 16px text at weight 400.** It does not exist in this system.
8. **No third-party icon kits, and no mixed icon sources inside a single view.** The MyFlicker set ships with this skill; there is no reason to reach outside it.
9. **No mono font or tabular figures on marketing or hero copy.**
10. **No layout-shifting states.** Hover, active, selected and disabled all preserve component geometry. Translation stays within 4px, scale never exceeds 1.05.
11. **No extra `opacity` on a token that already carries alpha.**
12. **No more than one primary CTA per view.**
13. **No fake charts, no stock photography, no invented logos.** If a visual is needed, compose it from `.mf-card`, `.mf-tag`, `.mf-avatar`, `.mf-progress` and 1px rules.
14. **No dark-mode-only or light-mode-only work.** MyFlicker product surfaces ship light-first; if you add dark, both modes must feel intentional.
15. **No bottom border on page headers.** MyFlicker does not use a dividing line below topbar / dashboard header rows. Content separation is achieved by surface layering and spacing alone — never by adding `border-bottom` to a header container.
16. **Never use `--bg-brand-subtle` as the page background and skip the white main panel.** The grey shell and the white content panel are two separate DOM elements. Setting `body { background: var(--bg-base-secondary) }` and placing cards directly on it collapses the surface ladder and removes the depth that makes the layout feel like MyFlicker. The white rounded `main-pane` is mandatory on every product screen (see Rule 7).

