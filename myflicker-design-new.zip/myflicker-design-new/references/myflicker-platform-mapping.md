# MyFlicker - Platform Mapping

---

## 1. HTML / CSS / WEB

### Font Loading

**No webfont is loaded.** MyFlicker rides the platform Chinese-first system stack. Declare this explicitly rather than silently assuming fonts exist.

```css
/* No @font-face, no Google Fonts link. */
--font-family-default: "PingFang SC", "SF Pro Text", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
--font-family-heading: "PingFang SC", "SF Pro", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
--font-family-metric:  "Inter", "PingFang SC", system-ui, -apple-system, sans-serif;
--font-family-mono:    "JetBrains Mono", ui-monospace, "SF Mono", Menlo, Consolas, monospace;
```

`Inter` and `JetBrains Mono` are optional refinements. If they are not installed, the stack degrades to the platform equivalents and the design still holds - `Inter` falls back to PingFang SC on KPI numerals, `JetBrains Mono` to SF Mono or Consolas on code. Ship the fallback. Do not add a Google Fonts link: it puts a network dependency into an artefact that is otherwise fully offline, and it blocks first paint for a refinement most viewers will not notice.

Never substitute a different display face. Hierarchy comes from size and weight within one family.

### Loading the stylesheets

The tokens and the component layer ship with this skill. Link them; do not retype them.

```html
<link rel="stylesheet" href="assets/myflicker-tokens.css">
<link rel="stylesheet" href="assets/myflicker-components.css">
<link rel="stylesheet" href="assets/myflicker-icons.css">
<script src="assets/myflicker-icons.js"></script>
```

`assets/myflicker-tokens.css` already contains the `:root` block, the `[data-theme="dark"]` block and the base reset. The listing below is that same block, reproduced so you can read the values inline and so you can inline them when the deliverable has to be a single self-contained file. If the two ever disagree, `assets/myflicker-tokens.css` is generated from `myflicker-design-model.yaml` and wins.

If the full MyFlicker Kit package happens to be on disk, its `colors_and_type.css` and `components.css` are the upstream originals and are interchangeable with the bundled pair.

### CSS Custom Properties - Primary Mode (Light)

```css
:root {
  /* ── radii ── */
  --radius-0: 0px;
  --radius-2: 2px;
  --radius-4: 4px;
  --radius-6: 6px;
  --radius-8: 8px;
  --radius-10: 10px;
  --radius-12: 12px;
  --radius-full: 999px;
  --border-width-default: 1px;

  /* ── spacing ── */
  --spacer-2: 2px;
  --spacer-3: 3px;
  --spacer-4: 4px;
  --spacer-6: 6px;
  --spacer-8: 8px;
  --spacer-10: 10px;
  --spacer-12: 12px;
  --spacer-16: 16px;
  --spacer-20: 20px;
  --spacer-24: 24px;
  --spacer-32: 32px;
  --spacer-40: 40px;
  --spacer-48: 48px;
  --spacer-64: 64px;

  /* ── icon sizes ── */
  --icon-size-12: 12px;
  --icon-size-14: 14px;
  --icon-size-16: 16px;
  --icon-size-20: 20px;
  --icon-size-24: 24px;

  /* ── families ── */
  --font-family-default: "PingFang SC", "SF Pro Text", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --font-family-heading: "PingFang SC", "SF Pro", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --font-family-metric: "Inter", "PingFang SC", system-ui, -apple-system, sans-serif;
  --font-family-mono: "JetBrains Mono", ui-monospace, "SF Mono", Menlo, Consolas, monospace;

  /* ── weights ── */
  --font-weight-default: 400;
  --font-weight-medium: 500;
  --font-weight-strong: 600;
  --font-weight-code: 450;

  /* ── type scale (canonical 7 + product baseline) ── */
  --display-font-size: 40px;      --display-line-height: 48px;      --display-font-weight: 600;
  --heading-font-size: 24px;      --heading-line-height: 32px;      --heading-font-weight: 600;
  --subheading-font-size: 16px;   --subheading-line-height: 24px;   --subheading-font-weight: 500;
  --body-font-size: 13px;         --body-line-height: 20px;         --body-font-weight: 400;
  --body-sm-font-size: 13px;      --body-sm-line-height: 20px;      --body-sm-font-weight: 400;
  --caption-font-size: 12px;      --caption-line-height: 18px;      --caption-font-weight: 400;
  --label-font-size: 13px;        --label-line-height: 20px;        --label-font-weight: 500;
  --code-editor-font-size: 13px;  --code-editor-line-height: 20px;  --code-editor-font-weight: 450;

  /* ── surfaces ── */
  --bg-base-default: #FFFFFF;
  --bg-base-secondary: #F5F7FA;
  --bg-base-tertiary: #F0F2F5;
  --bg-brand-subtle: #F6F6F6;
  --bg-brand-subtle-hover: #EDEDED;
  --bg-menu: #FFFFFF;
  --bg-tooltip: #242323;
  --bg-mask: rgba(0, 0, 0, 0.45);
  --bg-overlay-l1: rgba(92, 96, 102, 0.08);
  --bg-overlay-l2: rgba(92, 96, 102, 0.12);
  --bg-overlay-l3: rgba(92, 96, 102, 0.16);
  --bg-overlay-l4: rgba(92, 96, 102, 0.20);
  --fill-default: #E1E3E6;
  --fill-secondary: #EBEDF0;

  /* ── brand ── */
  --bg-brand: #242323;
  --bg-brand-hover: #4D4D4D;
  --bg-brand-active: #000000;
  --bg-brand-disabled: rgba(36, 35, 35, 0.22);
  --bg-brand-popup: rgba(36, 35, 35, 0.10);
  --bg-invert: #242323;
  --bg-invert-hover: #4D4D4D;
  --bg-invert-active: #000000;
  --bg-invert-disabled: rgba(36, 35, 35, 0.20);

  /* ── text ── */
  --text-default: #1F2329;
  --text-default-hover: #0D0E0F;
  --text-secondary: #5C6066;
  --text-tertiary: #95999E;
  --text-disabled: #C4C7CC;
  --text-onbrand: #FFFFFF;
  --text-onaccent: #FFFFFF;
  --text-white: #FFFFFF;

  /* ── icon ── */
  --icon-default: #1F2329;
  --icon-secondary: #5C6066;
  --icon-tertiary: #95999E;
  --icon-disabled: #C4C7CC;
  --icon-onbrand: #FFFFFF;
  --icon-onaccent: #FFFFFF;

  /* ── border ── */
  --border-neutral-l1: #EBEDF0;
  --border-neutral-l2: #E1E3E6;
  --border-neutral-subtle: #F0F2F5;
  --border-brand: #242323;
  --border-brand-hover: #4D4D4D;

  /* ── status ── */
  --status-success-default: #20BD6E;
  --status-success-hover: #32E485;
  --status-success-active: #129659;
  --status-success-surface-l1: rgba(32, 189, 110, 0.12);
  --status-success-surface-l2: rgba(32, 189, 110, 0.18);
  --status-success-surface-l3: rgba(32, 189, 110, 0.36);
  --status-warning-default: #FFB641;
  --status-warning-hover: #FFCA69;
  --status-warning-active: #D9912B;
  --status-warning-surface-l1: rgba(255, 182, 65, 0.12);
  --status-warning-surface-l2: rgba(255, 182, 65, 0.16);
  --status-warning-surface-l3: rgba(255, 182, 65, 0.36);
  --status-error-default: #FF3135;
  --status-error-hover: #FF5C59;
  --status-error-active: #D91E28;
  --status-error-surface-l1: rgba(255, 49, 53, 0.12);
  --status-error-surface-l2: rgba(255, 49, 53, 0.16);
  --status-error-surface-l3: rgba(255, 49, 53, 0.36);
  --status-primary-default: #1380ED;
  --status-primary-hover: #339CFF;
  --status-primary-active: #0A74DF;
  --status-primary-surface-l1: rgba(19, 128, 237, 0.12);
  --status-primary-surface-l2: rgba(19, 128, 237, 0.18);
  --status-primary-surface-l3: rgba(19, 128, 237, 0.36);
  --bg-success: #F0FFF4;
  --bg-warning: #FFFCF0;
  --bg-error: #FFF2F0;
  --bg-info: #E5F2FF;

  /* ── motion ── */
  --duration-micro: 120ms;
  --duration-normal: 200ms;
  --duration-layout: 300ms;
  --easing-default: ease;
}
```

### Secondary Mode (Dark)

Applied via `<html data-theme="dark">`. Never via `prefers-color-scheme` - MyFlicker product surfaces ship light-first and dark is an explicit opt-in.

```css
[data-theme="dark"] {
  --bg-base-default: #17181A;
  --bg-base-secondary: #121314;
  --bg-base-tertiary: #27292B;
  --bg-brand-subtle: #242323;
  --bg-menu: #27292B;
  --bg-tooltip: #2D2F32;
  --bg-mask: rgba(0, 0, 0, 0.60);
  --bg-overlay-l1: rgba(255, 255, 255, 0.06);
  --bg-overlay-l2: rgba(255, 255, 255, 0.10);
  --bg-overlay-l3: rgba(255, 255, 255, 0.14);
  --bg-overlay-l4: rgba(255, 255, 255, 0.18);
  --fill-default: #2D2F32;

  --bg-brand: #4F4F4F;
  --bg-brand-hover: #666666;
  --bg-brand-active: #383838;
  --bg-invert: #EDEDED;
  --bg-invert-hover: #FFFFFF;
  --bg-invert-active: #D9D9D9;

  --text-default: #E8EAED;
  --text-secondary: #9EA3A8;
  --text-tertiary: #5C6066;
  --text-disabled: #3A3D42;

  --icon-default: #E8EAED;
  --icon-secondary: #9EA3A8;
  --icon-tertiary: #5C6066;
  --icon-disabled: #3A3D42;

  --border-neutral-l1: #2D2F32;
  --border-neutral-l2: #404347;
  --border-neutral-subtle: #27292B;
  --border-brand: #C5C3C3;
  --border-brand-hover: #EDEDED;

  --status-success-default: #129659;
  --status-warning-default: #D9912B;
  --status-error-default: #D91E28;
  --status-primary-default: #0A74DF;
  --bg-success: rgba(32, 189, 110, 0.12);
  --bg-warning: rgba(255, 182, 65, 0.12);
  --bg-error: rgba(255, 49, 53, 0.12);
  --bg-info: rgba(19, 128, 237, 0.12);
}
```

### Base reset

```css
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  background: var(--bg-base-default);
  color: var(--text-default);
  font-family: var(--font-family-default);
  font-size: var(--body-sm-font-size);
  line-height: var(--body-sm-line-height);
  font-weight: var(--body-sm-font-weight);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
a { color: var(--text-default); text-decoration: none; }
a:hover { color: var(--text-default-hover); }
hr { border: 0; border-top: 1px solid var(--border-neutral-l1); }
.icon svg, .icon svg * { fill: currentColor; }
@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; animation: none !important; }
}
```

---

## 2. REACT / TAILWIND

### tailwind.config.js

```js
module.exports = {
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: 'var(--bg-base-default)',
          secondary: 'var(--bg-base-secondary)',
          tertiary: 'var(--bg-base-tertiary)',
          chrome: 'var(--bg-brand-subtle)',
          menu: 'var(--bg-menu)',
          tooltip: 'var(--bg-tooltip)',
        },
        overlay: {
          1: 'var(--bg-overlay-l1)',
          2: 'var(--bg-overlay-l2)',
          3: 'var(--bg-overlay-l3)',
          4: 'var(--bg-overlay-l4)',
        },
        brand: {
          DEFAULT: 'var(--bg-brand)',
          hover: 'var(--bg-brand-hover)',
          active: 'var(--bg-brand-active)',
          subtle: 'var(--bg-brand-subtle)',
        },
        fg: {
          DEFAULT: 'var(--text-default)',
          secondary: 'var(--text-secondary)',
          tertiary: 'var(--text-tertiary)',
          disabled: 'var(--text-disabled)',
          onbrand: 'var(--text-onbrand)',
        },
        line: {
          DEFAULT: 'var(--border-neutral-l1)',
          strong: 'var(--border-neutral-l2)',
          subtle: 'var(--border-neutral-subtle)',
          brand: 'var(--border-brand)',
        },
        status: {
          success: 'var(--status-success-default)',
          warning: 'var(--status-warning-default)',
          error: 'var(--status-error-default)',
          info: 'var(--status-primary-default)',
        },
      },
      fontFamily: {
        sans: ['PingFang SC', 'SF Pro Text', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        heading: ['PingFang SC', 'SF Pro', 'system-ui', '-apple-system', 'sans-serif'],
        metric: ['Inter', 'PingFang SC', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SF Mono', 'Menlo', 'Consolas', 'monospace'],
      },
      fontSize: {
        // [size, { lineHeight, fontWeight }] - take the pair, never mix
        'body-xs':   ['12px', { lineHeight: '18px', fontWeight: '400' }],
        'body-sm':   ['13px', { lineHeight: '20px', fontWeight: '400' }],
        'label':     ['13px', { lineHeight: '20px', fontWeight: '500' }],
        'heading-xs':['13px', { lineHeight: '20px', fontWeight: '600' }],
        'subheading':['16px', { lineHeight: '24px', fontWeight: '500' }],
        'heading-sm':['16px', { lineHeight: '24px', fontWeight: '600' }],
        'heading-md':['18px', { lineHeight: '28px', fontWeight: '600' }],
        'heading-lg':['20px', { lineHeight: '28px', fontWeight: '600' }],
        'heading-xl':['24px', { lineHeight: '32px', fontWeight: '600' }],
        'heading-2xl':['28px',{ lineHeight: '36px', fontWeight: '600' }],
        'heading-3xl':['32px',{ lineHeight: '40px', fontWeight: '600' }],
        'display':   ['40px', { lineHeight: '48px', fontWeight: '600', letterSpacing: '-0.02em' }],
        'code':      ['13px', { lineHeight: '20px', fontWeight: '450' }],
        'terminal':  ['12px', { lineHeight: '18px', fontWeight: '450' }],
      },
      spacing: {
        '0.5': '2px', '0.75': '3px', '1': '4px', '1.5': '6px', '2': '8px',
        '2.5': '10px', '3': '12px', '4': '16px', '5': '20px', '6': '24px',
        '8': '32px', '10': '40px', '12': '48px', '16': '64px',
      },
      borderRadius: {
        element: '2px',
        control: '4px',
        avatar: '6px',
        component: '8px',
        container: '12px',
        pill: '999px',
      },
      boxShadow: {
        none: 'none',
        menu: '0 12px 32px color-mix(in srgb, var(--text-default) 12%, transparent), 0 2px 8px color-mix(in srgb, var(--text-default) 8%, transparent)',
        popover: '0 12px 32px color-mix(in srgb, var(--text-default) 16%, transparent)',
        dialog: '0 24px 64px color-mix(in srgb, var(--text-default) 14%, transparent), 0 4px 16px color-mix(in srgb, var(--text-default) 8%, transparent)',
        composer: '0 4px 13.7px 6px rgba(21, 21, 21, 0.05)',
      },
      transitionDuration: {
        micro: '120ms',
        normal: '200ms',
        layout: '300ms',
      },
    },
  },
  darkMode: ['selector', '[data-theme="dark"]'],
};
```

### Component example

```tsx
export function Button({
  variant = 'secondary',
  size = 'md',
  ...props
}: ButtonProps) {
  const base =
    'inline-flex items-center justify-center gap-1.5 rounded-component border ' +
    'whitespace-nowrap select-none text-body-sm transition-colors duration-micro ' +
    'disabled:cursor-not-allowed';

  const sizes = {
    sm: 'h-6 px-2',
    md: 'h-7 px-3',
    lg: 'h-8 px-4',
  };

  const variants = {
    // one primary per view
    primary: 'bg-brand border-brand text-fg-onbrand hover:bg-brand-hover active:bg-brand-active disabled:bg-brand/20 disabled:text-fg-disabled',
    // hover changes TEXT colour, not background
    secondary: 'bg-bg border-line text-fg hover:text-fg-secondary active:text-fg-tertiary disabled:text-fg-disabled',
    tertiary: 'bg-transparent border-transparent text-fg hover:text-fg-secondary active:text-fg-tertiary',
    danger: 'bg-status-error border-status-error text-white',
  };

  return <button className={`${base} ${sizes[size]} ${variants[variant]}`} {...props} />;
}
```

### CSS Variables in React

Drop the `:root` and `[data-theme="dark"]` blocks into a global stylesheet imported once at the app root. Toggle mode with `document.documentElement.dataset.theme = 'dark'`. Never read tokens through JS objects - the CSS variable layer is the contract.

---

## 3. SWIFTUI / iOS

### Font Registration

No custom font bundling required. Map to the system font; PingFang SC is the system Chinese face on iOS.

```swift
extension Font {
  static let mfDisplay      = Font.system(size: 40, weight: .semibold)
  static let mfHeadingXL    = Font.system(size: 24, weight: .semibold)
  static let mfHeadingLG    = Font.system(size: 20, weight: .semibold)
  static let mfHeadingSM    = Font.system(size: 16, weight: .semibold)
  static let mfSubheading   = Font.system(size: 16, weight: .medium)
  static let mfBody         = Font.system(size: 13, weight: .regular)
  static let mfLabel        = Font.system(size: 13, weight: .medium)
  static let mfBodyBold     = Font.system(size: 13, weight: .semibold)
  static let mfCaption      = Font.system(size: 12, weight: .regular)
  static let mfCode         = Font.system(size: 13, weight: .regular, design: .monospaced)
  static let mfTerminal     = Font.system(size: 12, weight: .regular, design: .monospaced)
  static let mfMetric       = Font.system(size: 32, weight: .semibold, design: .default)
}
```

Line heights are enforced with `.lineSpacing()`: body 13/20 → `lineSpacing(7)`; heading 16/24 → `lineSpacing(8)`.

### Color Extension

```swift
import SwiftUI

extension Color {
  init(light: String, dark: String) {
    self.init(UIColor { $0.userInterfaceStyle == .dark ? UIColor(hex: dark) : UIColor(hex: light) })
  }

  // surfaces
  static let mfBackground      = Color(light: "#FFFFFF", dark: "#17181A")
  static let mfSurface1        = Color(light: "#F5F7FA", dark: "#121314")
  static let mfSurface2        = Color(light: "#F0F2F5", dark: "#27292B")
  static let mfChrome          = Color(light: "#F6F6F6", dark: "#242323")
  static let mfMenu            = Color(light: "#FFFFFF", dark: "#27292B")
  static let mfTooltip         = Color(light: "#242323", dark: "#2D2F32")

  // overlays
  static let mfOverlay1        = Color(light: "#5C6066", dark: "#FFFFFF").opacity(0.08)
  static let mfOverlay2        = Color(light: "#5C6066", dark: "#FFFFFF").opacity(0.12)
  static let mfOverlay3        = Color(light: "#5C6066", dark: "#FFFFFF").opacity(0.16)

  // brand
  static let mfBrand           = Color(light: "#242323", dark: "#4F4F4F")
  static let mfBrandHover      = Color(light: "#4D4D4D", dark: "#666666")
  static let mfBrandActive     = Color(light: "#000000", dark: "#383838")
  static let mfBrandSubtle     = Color(light: "#F6F6F6", dark: "#242323")

  // text
  static let mfText1           = Color(light: "#1F2329", dark: "#E8EAED")
  static let mfText2           = Color(light: "#5C6066", dark: "#9EA3A8")
  static let mfText3           = Color(light: "#95999E", dark: "#5C6066")
  static let mfText4           = Color(light: "#C4C7CC", dark: "#3A3D42")
  static let mfOnBrand         = Color.white

  // border
  static let mfBorder          = Color(light: "#EBEDF0", dark: "#2D2F32")
  static let mfBorderStrong    = Color(light: "#E1E3E6", dark: "#404347")
  static let mfBorderSubtle    = Color(light: "#F0F2F5", dark: "#27292B")

  // status
  static let mfSuccess         = Color(light: "#20BD6E", dark: "#129659")
  static let mfWarning         = Color(light: "#FFB641", dark: "#D9912B")
  static let mfError           = Color(light: "#FF3135", dark: "#D91E28")
  static let mfInfo            = Color(light: "#1380ED", dark: "#0A74DF")
}
```

### Spacing & Radius Constants

```swift
struct MFSpacing {
  static let xxs: CGFloat = 2
  static let xs:  CGFloat = 4
  static let s:   CGFloat = 6
  static let sm:  CGFloat = 8
  static let md:  CGFloat = 12
  static let lg:  CGFloat = 16
  static let xl:  CGFloat = 20
  static let xxl: CGFloat = 24
  static let section: CGFloat = 32
  static let region:  CGFloat = 48

  /// Minimum gap between two containers. 4/6/8 are intra-row only.
  static let containerGapMin: CGFloat = 16
  static let pagePadding: CGFloat = 32
}

struct MFRadius {
  static let element:   CGFloat = 2
  static let control:   CGFloat = 4
  static let avatar:    CGFloat = 6
  static let component: CGFloat = 8
  static let container: CGFloat = 12
  static let pill:      CGFloat = 999
}

struct MFMotion {
  static let micro  = Animation.easeInOut(duration: 0.12)
  static let normal = Animation.easeInOut(duration: 0.20)
  static let layout = Animation.easeInOut(duration: 0.30)
}
```

### Dark/Light Mode

The `Color(light:dark:)` initializer resolves per `userInterfaceStyle`, so a single declaration covers both modes. MyFlicker surfaces default to light; do not force `.preferredColorScheme(.dark)`.

Elevation on iOS keeps the borders-first strategy: use `.overlay(RoundedRectangle(cornerRadius: MFRadius.container).stroke(Color.mfBorder, lineWidth: 1))` instead of `.shadow()` on cards. Reserve `.shadow()` for sheets, menus and popovers.

---

## 4. ICON MAPPING

The 266-glyph MyFlicker set is bundled with this skill at `assets/`. There is no CDN dependency and no fallback kit.

| Platform | Source | Pattern |
|---|---|---|
| Web, any context | `assets/myflicker-icons.js` | `<svg class="mf-icon"><use href="#mf-search"></use></svg>` |
| Web, build pipeline | `assets/myflicker-icons.svg` | inline the sprite into the document head server-side, then `<use>` |
| React | `assets/myflicker-icons.js` loaded once at the app root | `<svg className="mf-icon"><use href="#mf-search" /></svg>` |
| React, typed | `assets/myflicker-icons.json` | generate a `IconName` union from `names`, then wrap `<use>` in an `<Icon name>` component |
| SwiftUI | export the needed glyphs to an asset catalog as template images | `Image("mf-search").renderingMode(.template)` |

Default render size 16px; 14px in dense rows; 20px for sidebar icon buttons; 24px only when the icon anchors a copy-led block. Colour always arrives through `currentColor`, so set `color` on the parent rather than styling the glyph.

Find a name in `icon-browser.html` or:

```js
MFIcons.names.filter(function (n) { return n.indexOf('add') === 0; });
// ["add", "addfiles", "addgroup", "addteam"]
```

**Never** substitute Lucide, Phosphor, Tabler or Font Awesome. If a glyph is missing, pick a semantically close one from the set, drop the icon and keep the label, or draw a new 1024-grid outline SVG in the same construction.
