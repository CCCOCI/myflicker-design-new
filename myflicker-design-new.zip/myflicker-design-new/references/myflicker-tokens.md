# MyFlicker - Tokens

Every value here is generated from `myflicker-design-model.yaml`. The upstream source is the MyFlicker Figma variable set, projected into `colors_and_type.css` in the MyFlicker Kit package.

---

## 0. PRIMITIVES

Raw ramps. Semantic tokens below reference these; product code references the semantic layer, never the primitives.

### Color Ramps

**Neutral (N100–N1000)** - cool-neutral greys with a faint blue cast. This is what makes MyFlicker read as a tool rather than a document.

| Step | Hex | Figma | Used by |
|---|---|---|---|
| 50 | `#FFFFFF` | N100 | page background, white fill |
| 100 | `#F5F7FA` | N200 | card / panel surface |
| 200 | `#F0F2F5` | N300 | tertiary surface, subtle border |
| 300 | `#EBEDF0` | N400 | default border |
| 400 | `#E6E8EB` | N500 | - |
| 500 | `#E1E3E6` | N600 | border hover, primary fill |
| 600 | `#C4C7CC` | N700 | disabled text |
| 700 | `#95999E` | N800 | tertiary text |
| 800 | `#5C6066` | N900 | secondary text |
| 900 | `#1F2329` | N1000 | default text |
| 950 | `#0D0E0F` | - | text hover |

**Brand (Primary 100–1100)** - near-black. Note the ramp is inverted relative to a chromatic brand: the primary step is **900**, not 500.

| Step | Hex | Figma | Used by |
|---|---|---|---|
| 50 | `#F6F6F6` | Primary 100 | app chrome, sidebar, brand subtle bg |
| 100 | `#EDEDED` | Primary 200 | brand subtle hover, menu item hover |
| 200 | `#DEDEDE` | Primary 300 | - |
| 300 | `#DDDBDB` | Primary 400 | - |
| 400 | `#D9D9D9` | Primary 500 | - |
| 500 | `#C5C3C3` | Primary 600 | dark-mode brand text |
| 600 | `#999696` | Primary 700 | - |
| 700 | `#737272` | Primary 800 | - |
| 800 | `#4D4D4D` | Primary 900 | **brand hover** |
| 900 | `#242323` | Primary 1000 | **PRIMARY BRAND** |
| 950 | `#000000` | Primary 1100 | **brand active** |

**Status ramps** - each carries a 100/200 background pair, a 500 hover, a 600 default and a 700 active.

| Ramp | 100 | 200 | 500 | 600 (default) | 700 |
|---|---|---|---|---|---|
| green | `#F0FFF4` | `#DBFFE7` | `#32E485` | `#20BD6E` | `#129659` |
| amber | `#FFFCF0` | `#FFF8E3` | `#FFCA69` | `#FFB641` | `#D9912B` |
| red | `#FFF2F0` | `#FFD9D4` | `#FF5C59` | `#FF3135` | `#D91E28` |
| blue | `#E5F2FF` | `#D9ECFF` | `#339CFF` | `#1380ED` | `#0A74DF` |
| purple | `#F9F0FF` | `#EFDBFF` | `#9254DE` | `#722ED1` | `#531DAB` |

**Purple is fill / border / background only. Never purple text.**

### Spacing Primitives

`0, 2, 3, 4, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64`

8 is the base step. 2 / 3 / 6 / 10 exist for dense control internals only.

### Radii Primitives

`0, 2, 4, 6, 8, 10, 12, 16, 20, 24, 32, 999`

8 is the default container radius; 12 is the card / dialog radius.

---

## 1. TYPOGRAPHY

### Font Stack

No webfont is loaded. MyFlicker rides the platform Chinese-first system stack.

```css
--font-family-default: "PingFang SC", "SF Pro Text", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
--font-family-heading: "PingFang SC", "SF Pro", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
--font-family-metric:  "Inter", "PingFang SC", system-ui, -apple-system, sans-serif;
--font-family-mono:    "JetBrains Mono", ui-monospace, "SF Mono", Menlo, Consolas, monospace;
```

| Role | Family | Why |
|---|---|---|
| Display / heading | PingFang SC | Same family as body. Hierarchy comes from size and weight, not from a contrasting face. |
| Body | PingFang SC | Chinese-first product; PingFang's 13px rendering is the reason 13px is viable as a baseline. |
| Metric | Inter | Only for large KPI numbers. Its lining figures hold at 32px+ where PingFang's numerals feel soft. |
| Mono | JetBrains Mono | Code, paths, shell, IDs, table numerals, keyboard hints. |

If `Inter` or `JetBrains Mono` is unavailable, the stack degrades to the platform equivalents. Do not substitute a different display face.

### Mono Font Rules

`mono_for_code: true`, `mono_for_metrics: true`.

**Mono applies to:** code blocks, inline code, file paths, shell commands, IDs, hashes, table numerals, chart axis labels, counts in dense rows, keyboard hints.

**Mono never applies to:** hero headlines, marketing copy, body prose, button labels, navigation labels, card titles.

Numeric cells add `font-variant-numeric: tabular-nums` so columns align.

### Type Scale

| Token | Size / Line | Weight | Usage |
|---|---|---|---|
| `display` | 40 / 48 | 600 | marketing hero only, `letter-spacing: -0.02em` |
| `heading-3xl` | 32 / 40 | 600 | marketing section headline |
| `heading-2xl` | 28 / 36 | 600 | marketing section headline |
| `heading-xl` | 24 / 32 | 600 | large page title |
| `heading-lg` | 20 / 28 | 600 | page title |
| `heading-md` | 18 / 28 | 600 | large section title (rare) |
| `heading-sm` | 16 / 24 | 600 | section title, card title, dialog title |
| `heading-xs` | 13 / 20 | 600 | dense subsection label |
| `body-lg` | 18 / 28 | 500 | oversized statement copy (rare) |
| `body-md-medium` | 16 / 24 | 500 | subheading, page tab label |
| `body-sm` | 13 / 20 | 400 | **product baseline** - everything |
| `body-sm-medium` | 13 / 20 | 500 | row title, active nav, table header |
| `body-sm-bold` | 13 / 20 | 600 | alert title, toast title |
| `body-xs` | 12 / 18 | 400 | helper text, meta, tag label, sidebar section label |
| `code-editor` | 13 / 20 | 450 | code blocks, diffs |
| `code-terminal` | 12 / 18 | 450 | terminal output |

### Typographic Rules

- `body-sm` (13/20) is the product baseline. Controls, list rows, table cells, form labels, helper text, tags and chips all sit here unless a denser primitive already exists.
- **16px only ever ships at weight 500 or 600.** There is no 16/400 style.
- Take a text style as a complete set: family + size + line-height + weight + letter-spacing. Never mix a size from one style with a weight from another.
- One locale per screen. Default to English copy unless the request is explicitly Chinese.
- Letter-spacing is 0 everywhere except `display` (`-0.02em`).

---

## 2. COLOR SYSTEM (Semantic Tokens)

### Primary Mode (Light)

| Role | CSS variable | Hex / value |
|---|---|---|
| Page background | `--bg-base-default` | `#FFFFFF` |
| Card / panel surface | `--bg-base-secondary` | `#F5F7FA` |
| Tertiary surface | `--bg-base-tertiary` | `#F0F2F5` |
| App chrome / sidebar | `--bg-brand-subtle` | `#F6F6F6` |
| Field / inline control | `--bg-overlay-l1` | `rgba(92,96,102,0.08)` |
| Hover | `--bg-overlay-l2` | `rgba(92,96,102,0.12)` |
| Pressed / selected | `--bg-overlay-l3` | `rgba(92,96,102,0.16)` |
| Strong overlay | `--bg-overlay-l4` | `rgba(92,96,102,0.20)` |
| Floating menu surface | `--bg-menu` | `#FFFFFF` |
| Tooltip surface | `--bg-tooltip` | `#242323` (inverted) |
| Default border | `--border-neutral-l1` | `#EBEDF0` |
| Border hover / visible | `--border-neutral-l2` | `#E1E3E6` |
| Subtle border | `--border-neutral-subtle` | `#F0F2F5` |
| Primary text | `--text-default` | `#1F2329` |
| Secondary text | `--text-secondary` | `#5C6066` |
| Tertiary text | `--text-tertiary` | `#95999E` |
| Disabled text | `--text-disabled` | `#C4C7CC` |
| Text on brand | `--text-onbrand` | `#FFFFFF` |
| Brand / accent | `--bg-brand`, `--bg-invert` | `#242323` |
| Brand hover | `--bg-brand-hover` | `#4D4D4D` |
| Brand active | `--bg-brand-active` | `#000000` |
| Brand disabled | `--bg-brand-disabled` | `rgba(36,35,35,0.22)` |
| Mask | `--bg-mask` | `rgba(0,0,0,0.45)` |

Icon tokens mirror the text ladder exactly: `--icon-default` = `#1F2329`, `--icon-secondary` = `#5C6066`, `--icon-tertiary` = `#95999E`, `--icon-disabled` = `#C4C7CC`.

### Secondary Mode (Dark)

Dark mode exists in the token file under `[data-theme="dark"]`. Product surfaces ship light-first; use dark only when the request asks for it, and never via `prefers-color-scheme`.

| Role | Value |
|---|---|
| Page background | `#17181A` |
| Card / panel surface | `#121314` |
| Tertiary surface | `#27292B` |
| App chrome | `#242323` |
| Overlays | `rgba(255,255,255, 0.06 / 0.10 / 0.14 / 0.18)` |
| Menu surface | `#27292B` |
| Tooltip | `#2D2F32` |
| Default border | `#2D2F32` |
| Border visible | `#404347` |
| Primary text | `#E8EAED` |
| Secondary text | `#9EA3A8` |
| Tertiary text | `#5C6066` |
| Disabled text | `#3A3D42` |
| Brand | `#4F4F4F` (hover `#666666`, active `#383838`) |
| Status defaults | success `#129659`, warning `#D9912B`, error `#D91E28`, info `#0A74DF` |

### Accent & Status Tints

| Semantic | Default | Hover | Active | Surface L1 (.12) | Background |
|---|---|---|---|---|---|
| success | `#20BD6E` | `#32E485` | `#129659` | `rgba(32,189,110,0.12)` | `#F0FFF4` |
| warning | `#FFB641` | `#FFCA69` | `#D9912B` | `rgba(255,182,65,0.12)` | `#FFFCF0` |
| error | `#FF3135` | `#FF5C59` | `#D91E28` | `rgba(255,49,53,0.12)` | `#FFF2F0` |
| info / link | `#1380ED` | `#339CFF` | `#0A74DF` | `rgba(19,128,237,0.12)` | `#E5F2FF` |
| purple (fill/border only) | `#722ED1` | `#9254DE` | `#531DAB` | `rgba(114,46,209,0.12)` | `#F9F0FF` |

Each status also has L2 (.18) and L3 (.36) surfaces for hover and strong states.

### Color Usage Rules

- **Brand colour is scarce.** Primary action, brand identity moments, small meaningful status accents. Never generic hover rows, inactive borders, tab underlines, or decorative fills. Tab underlines use `--icon-default`.
- **Interactive neutral states climb the overlay ladder:** default surface → `l1` → `l2` → `l3` for pressed / selected.
- **Status colour is semantic.** Use `--status-*-default` plus the matching `--status-*-surface-*` only for real info / success / warning / error meaning.
- **Never stack `opacity` on a token that already carries alpha.**
- Purple is a fill / border / background accent only. There is no purple text token.

---

## 3. SPACING

### Scale (8px base)

| Token | Value | Use |
|---|---|---|
| `--spacer-2` | 2px | micro nudge, meta line gap |
| `--spacer-3` | 3px | scrollbar width |
| `--spacer-4` | 4px | icon-to-icon, pill tab gap, shell gap |
| `--spacer-6` | 6px | icon-to-label inside buttons and tags |
| `--spacer-8` | 8px | base intra-row gap, button group gap |
| `--spacer-10` | 10px | dense cell gap |
| `--spacer-12` | 12px | button horizontal padding, table cell padding |
| `--spacer-16` | 16px | **minimum gap between related containers** |
| `--spacer-20` | 20px | card padding, card grid gap |
| `--spacer-24` | 24px | gap between card groups, underline tab gap |
| `--spacer-32` | 32px | desktop page padding, gap between page sections |
| `--spacer-40` | 40px | empty-state vertical padding |
| `--spacer-48` | 48px | gap between major regions |
| `--spacer-64` | 64px | marketing section rhythm |

**Two dialects, never mixed.** 4 / 6 / 8 are intra-row. 16 / 24 / 32 / 48 are inter-container. Never use 4, 6 or 8 as the gap between two containers.

Page padding: 32px desktop, 16px mobile.

---

## 4. BORDERS & RADII

### Radii Scale (Semantic → Primitive)

| Semantic | Value | Applies to |
|---|---|---|
| element | 2px | checkbox |
| control | 4px | tag, small chip, icon button in sidebar |
| avatar | 6px | workspace avatar |
| component | 8px | **default** - buttons, inputs, selects, menu items, shell panes, alerts, toasts |
| container | 12px | cards, dialogs, menus, popovers, chat composer |
| pill | 999px | switch, radio dot, progress track, count badge, avatar |

Radii above 12px (16 / 20 / 24 / 32) exist in the primitive scale for special surfaces but are not part of the standard component API.

### Border Treatment

- Border width is always `1px` (`--border-width-default`). The one exception is the 1.5px ring on stacked avatars, which is a background-coloured separator rather than a border.
- Default border `#EBEDF0`. Hover / visible border `#E1E3E6`. Subtle divider `#F0F2F5`.
- Dividers inside a container are 1px full-bleed rules, not padded segments.
- Dashed borders are reserved for empty states.

---

## 5. ELEVATION & SHADOWS

Strategy: **borders-first.** Depth is a 1px border plus one surface step. Shadows only for genuinely floating layers.

| Layer | Shadow |
|---|---|
| Card, panel, alert, toast (inline) | `none` |
| Menu | `0 12px 32px color-mix(in srgb, var(--text-default) 12%, transparent), 0 2px 8px color-mix(in srgb, var(--text-default) 8%, transparent)` |
| Popover, tooltip | `0 12px 32px color-mix(in srgb, var(--text-default) 16%, transparent)` |
| Dialog | `0 24px 64px color-mix(in srgb, var(--text-default) 14%, transparent), 0 4px 16px color-mix(in srgb, var(--text-default) 8%, transparent)` |
| Chat composer | `0 4px 13.7px 6px rgba(21, 21, 21, 0.05)` |
| Floating toast | `0 4px 16px rgba(0,0,0,0.10), 0 1px 4px rgba(0,0,0,0.06)` |

Forbidden: shadows on cards, shadows on buttons, coloured shadows, glow.

---

## 6. MOTION & INTERACTION

### Personality

Functional. Motion confirms a state change and then gets out of the way. Nothing in MyFlicker eases decoratively.

### Timing

| Duration | Applies to |
|---|---|
| 120ms | hover, focus, colour and border changes |
| 200ms | component state change, toast in / out |
| 300ms (max) | layout reveal, panel expand |

Easing: `ease`. No spring, no bounce, no custom cubic curves.

### Interaction States

| State | Treatment |
|---|---|
| hover (row / control) | background steps to `--bg-overlay-l2`, or text colour steps one level lighter for text buttons |
| pressed / selected | background `--bg-overlay-l3` |
| focus | `border-color: --border-brand`. No ring, no glow. |
| disabled | `--text-disabled` foreground, `--bg-brand-disabled` or `--bg-base-secondary` surface, `cursor: not-allowed` |
| loading | `.mf-skeleton` shimmer, 1.6s ease-in-out infinite |

Animated properties are limited to `opacity`, `background`, `color`, `border-color`, and `transform` with translation ≤ 4px. Scale never exceeds 1.05. **State changes must not shift layout geometry.** Under `prefers-reduced-motion`, drop all non-essential transitions and all translation.

---

## 7. ICONOGRAPHY

### The set is bundled with this skill

**Use `assets/myflicker-icons.js`. It carries the real MyFlicker glyphs, so there is no reason to reach for a third-party kit.**

266 glyphs from the first-party `@kid/enterprise-icon` set at version 1.0.1070, converted into a self-injecting SVG sprite. Every glyph is normalised to `currentColor`, so it inherits the surrounding text colour with no extra CSS. Visually: outline-only, geometric construction, soft terminals, roughly a 2px stroke at 16px render size, minimal interior detail.

| Attribute | Value |
|---|---|
| stroke_weight | medium (~2px at 16px) |
| corner_treatment | soft |
| fill_style | outline |
| form_language | geometric |
| visual_density | minimal |
| viewBox | `0 0 1024 1024` |
| colour | `currentColor` |

### Bundled assets

| File | Size | Purpose |
|---|---|---|
| `assets/myflicker-icons.js` | 245 KB | self-injecting sprite plus `window.MFIcons`. **This is the one file you need.** |
| `assets/myflicker-icons.svg` | 238 KB | the raw sprite, for build pipelines that inline it server-side |
| `assets/myflicker-icons.css` | 1 KB | `.mf-icon` sizing and colour helpers |
| `assets/myflicker-icons.json` | 4 KB | the name index, for programmatic lookup |
| `icon-browser.html` | - | searchable visual index, click a tile to copy its markup |

### Usage

```html
<link rel="stylesheet" href="assets/myflicker-icons.css">
<script src="assets/myflicker-icons.js"></script>

<!-- default 16px, inherits the parent colour -->
<svg class="mf-icon"><use href="#mf-search"></use></svg>

<!-- explicit size and colour -->
<svg class="mf-icon mf-icon--20 mf-icon--secondary"><use href="#mf-setting"></use></svg>

<!-- inside a button, colour comes from the button -->
<button class="mf-btn mf-btn--primary">
  <svg class="mf-icon mf-icon--14"><use href="#mf-add"></use></svg>New session
</button>
```

The symbol id is always `mf-{name}`. The script injects the sprite on `DOMContentLoaded` and works under `file://` as well as over http, so a single generated HTML file opens correctly with a double click.

There is also a shorthand that gets upgraded automatically on load:

```html
<i class="mf-icon" data-icon="search"></i>
```

### Finding a glyph name

Open `icon-browser.html` and filter, or read `assets/myflicker-icons.json`. Names are short and lowercase, no separators: `add`, `close`, `search`, `edit`, `delete`, `setting`, `share`, `person`, `home`, `agent`, `brain`, `canvas`, `check`, `archive`, `attention`.

```js
MFIcons.names.filter(function (n) { return n.indexOf('add') === 0; });
// ["add", "addfiles", "addgroup", "addteam"]
```

### If a glyph is genuinely missing

Do **not** pull in Lucide, Phosphor, Tabler or Font Awesome to fill the gap. Mixing sources is the single most visible way to break the system. In order of preference:

1. Pick a semantically close glyph that already exists in the set.
2. Drop the icon and keep the text label.
3. Draw one 1024-grid outline SVG in the same construction and add it to the sprite.

*Provenance: converted from `@kid/enterprise-icon@1.0.1070`. Hard-coded `#898A8C` fills and strokes were rewritten to `currentColor`; geometry is untouched.*

### Sizes

Sizes refer to rendered width and height, regardless of `viewBox`.

| Size | Class | Use |
|---|---|---|
| 12px | `.mf-icon--12` | inside a tag |
| 14px | `.mf-icon--14` | dense controls, menus, input adornments, tight rows |
| 16px | default | **default** |
| 20px | `.mf-icon--20` | sidebar icon buttons, model picker rows |
| 24px | `.mf-icon--24` | copy-led pages, cards where the icon anchors the block |

Every icon reserves its final width and height from the `.mf-icon` class, so nothing shifts as the sprite injects.

### Color rule

Icons inherit colour from text. `--icon-default` matches `--text-default`, `--icon-secondary` matches `--text-secondary`, `--icon-tertiary` matches `--text-tertiary`. Status icons take `--status-*-default`.

Prefer setting `color` on the parent. The `.mf-icon--secondary` / `--tertiary` / `--success` / `--warning` / `--error` / `--info` helpers exist only for the cases where the parent colour is already correct for its own text and the icon needs to differ.

### Don't

- Don't mix icon sources. The bundled set is the only source.
- Don't hard-code a `fill` or `stroke` colour on a glyph; that defeats `currentColor`.
- Don't scale a glyph with `transform`; use the size classes so layout stays honest.
- Don't use icons as decoration or in clusters.
- Don't apply a background chip behind an icon unless the component spec defines one.
