# MyFlicker - Components

Every component here is `source: observed` - extracted from `components.css` in the MyFlicker Kit package. All classes use the `.mf-` prefix and form the stable component API.

**The executable version of this file is `assets/myflicker-components.css`.** Link that and use the classes; it ships with this skill and needs no other dependency. Read the tables below when you need to know why a value is what it is, when you are porting to React Native or SwiftUI, or when you are extending the system. Do not hand-transcribe these tables back into CSS.

Producing a single self-contained file is not a reason to retype the specs either - inline `assets/myflicker-tokens.css` and `assets/myflicker-components.css` verbatim instead.

---

## 1. BUTTONS

### Variants

| Variant | Class | Background | Text | Border |
|---|---|---|---|---|
| Primary | `.mf-btn--primary` | `#242323` | `#FFFFFF` | `#242323` |
| Secondary | `.mf-btn--secondary` | `--bg-base-default` | `--text-default` | `--border-neutral-l1` |
| Tertiary | `.mf-btn--tertiary` | transparent | `--text-default` | transparent |
| Ghost | `.mf-btn--ghost` | transparent | `--text-default` | transparent (alias of tertiary) |
| Danger | `.mf-btn--danger` | `#FF3135` | `#FFFFFF` | `#FF3135` |
| Danger subtle | `.mf-btn--danger-subtle` | `rgba(255,49,53,0.12)` | `#FF3135` | transparent |
| Warning | `.mf-btn--warning` | `#FFB641` | `#FFFFFF` | `#FFB641` |
| Brand | `.mf-btn--brand` | `--bg-brand` | `--text-onbrand` | `--bg-brand` |
| Link | `.mf-btn--link` | transparent | `--text-default` | none, padding 0, height auto |

### Specs

| Property | Value |
|---|---|
| Display | `inline-flex`, centred, `gap: 6px` |
| Height | 28px default |
| Padding | `0 12px` |
| Radius | 8px |
| Border | `1px solid transparent` |
| Font | `body-sm` - 13 / 20 / 400 |
| Icon | 16px, `fill: currentColor` |
| Transition | `120ms ease` on background, color, border-color, opacity |
| White-space | `nowrap`, `user-select: none` |

**Sizes:** `--sm` 24px height / `0 8px` padding · `--md` 28px / `0 12px` · `--lg` 32px / `0 16px`.
**Icon-only:** `.mf-btn--icon` → 28px square (24px with `--sm`, 32px with `--lg`), `padding: 0`. Requires `aria-label`.
**Group:** `.mf-btn-group` - children lose radius except first (left corners) and last (right corners), `margin-left: -1px`.

### States

| State | Primary | Secondary / Tertiary |
|---|---|---|
| hover | background `#4D4D4D` | **text colour steps to `--text-secondary`**, background unchanged |
| active | background `#000000` | text colour steps to `--text-tertiary` |
| disabled | background `rgba(36,35,35,0.20)`, text `--text-disabled` | text `--text-disabled`, `cursor: not-allowed` |
| focus | border-color `--border-brand` | same |

> Secondary and tertiary hover changing **text colour, not background** is a MyFlicker signature. Do not "fix" it to a background hover.

**Rule: one primary button per view.** If two actions tie in weight, demote both to secondary.

---

## 2. CARDS / SURFACES

### Standard Card - `.mf-card`

| Property | Value |
|---|---|
| Background | `--bg-base-secondary` `#F5F7FA` |
| Border | `1px solid --border-neutral-l1` |
| Radius | 12px |
| Padding | 20px |
| Shadow | none |
| Title | `heading-sm` (16/24/600), `margin-bottom: 8px` |
| Description | `body-sm`, `--text-secondary` |

### Entity Card - `.mf-entity-card`

Management-type card for owned assets (workflows, knowledge bases, skills).

| Property | Value |
|---|---|
| Min-height | 116px |
| Padding | 16px |
| Background | `--bg-base-default` (white, sits on a tinted page) |
| Border | `1px solid --border-neutral-l1` |
| Radius | 12px |
| Hover | background `--bg-base-secondary`, transition `120ms` |

### Grid - `.mf-card-grid`

`display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px; align-content: start;`
Variants: `--2col` (`minmax(420px, 1fr)`), `--3col` (`repeat(3, minmax(0, 1fr))`).

### Content Layout

Card interior stacks: title (`heading-sm` or `body-sm-medium`) → description (`body-sm`, `--text-secondary`) → meta row (`body-xs`, `--text-tertiary`) → tag row. Gaps of 4 / 8px inside the card; the 20px card gap does the outer separation.

**Never nest `.mf-card` inside `.mf-card`.** Use a single surface with internal 1px dividers.

---

## 3. INPUTS

### Text Field - `.mf-input`

| Property | Value |
|---|---|
| Display | `flex`, centred, `gap: 8px` |
| Min-height | 32px |
| Padding | `0 12px` |
| Background | `--bg-base-default` |
| Border | `1px solid --border-neutral-l1` |
| Radius | 8px |
| Font | `body-sm` |
| Width | 100% |

The inner `<input>` is transparent, borderless, `outline: none`, `font: inherit`, `min-width: 0`.

### Label

`body-sm` at `--text-default`, 4px above the field. Helper text is `body-xs` at `--text-tertiary`, 4px below.

### States

| State | Treatment |
|---|---|
| focus-within | `border-color: --border-brand` (`#242323`). No ring, no glow, no shadow. |
| error (`.is-error`) | `border-color: --status-error-default` |
| disabled (`.is-disabled`) | background `--bg-base-secondary`, colour `--text-disabled`, `cursor: not-allowed` |
| placeholder | `--text-tertiary` |

Number inputs suppress spinners (`appearance: textfield` plus the webkit spin-button reset).
Leading / trailing adornments use `.mf-input__icon` at `--icon-secondary`.

### Multiline - `.mf-textarea`

Min-height 96px, padding `8px 12px`, radius 8px, `resize: none`, same border and focus behaviour.

### Compact search field

Dense toolbars use a 28px-high field: `height: 28px; padding: 0 10px 0 28px;` with a 14px search icon absolutely positioned at `left: 8px` in `--icon-tertiary`. Focus steps the border to `--border-neutral-l2`.

---

## 4. LISTS / DATA ROWS

### Standard Row - `.mf-aside__session` / `.mf-menu__item` pattern

| Property | Value |
|---|---|
| Height | 32px |
| Padding | `0 8px` |
| Radius | 8px |
| Font | `body-sm` |
| Gap | 8px between icon and label |
| Icon | 16px at `--icon-secondary` |

### Interaction States

| State | Background |
|---|---|
| default | transparent |
| hover | `--bg-overlay-l2` (or `--fill-default` `#E1E3E6` in the sidebar) |
| selected / active | `--bg-overlay-l3` (or `--fill-default` in the sidebar), label weight steps to 500 |
| disabled | `--text-disabled`, no background change |

Trailing meta (timestamp, actions) appears on hover via `opacity: 0 → 1` over 120ms. **The row height must not change.**

### Item Cell - `.mf-item-cell`

Icon + title + description block used across list pages.

| Part | Spec |
|---|---|
| Wrapper | `flex`, centred, `gap: 10px`, `min-width: 0` |
| Icon box | 36px square, radius 8px, `1px solid --border-neutral-l1`, background `--bg-base-secondary` |
| Name | `body-sm` weight 500, `--text-default`, ellipsis |
| Description | 12 / 18, `--text-tertiary`, ellipsis |

### Data Row (Label + Value)

Label `body-sm` at `--text-secondary` on the left, value `body-sm` at `--text-default` right-aligned. Numeric values switch to `--code-editor-font-family` with `tabular-nums`. Rows are separated by 1px `--border-neutral-l1` dividers, not by spacing.

---

## 5. NAVIGATION / TAB BAR

### Underline Tabs - `.mf-tabs` / `.mf-tab`

| Property | Value |
|---|---|
| Container | `flex`, `gap: 24px`, `border-bottom: 1px solid --border-neutral-l1` |
| Tab padding | `12px 0` |
| Font | `body-sm` weight 500 |
| Default colour | `--text-tertiary` |
| Hover colour | `--text-default` |
| Active | colour `--text-default` + a 2px bar in `--icon-default` at `bottom: -1px` |

**The active indicator is neutral, not brand.**

Count badges: `.mf-tab__count` - min-width 18px, height 18px, radius 999px, background `--bg-overlay-l2`, colour `--text-tertiary`, metric font, `tabular-nums`.

### Pill Tabs - `.mf-tabs--pill` / `.mf-tab--pill`

| Property | Value |
|---|---|
| Container | `inline-flex`, `gap: 4px`, no bottom border |
| Tab | height 28px, padding `4px 12px`, radius 8px |
| Font | `body-sm` (400) |
| Default | transparent background, `--text-tertiary` |
| Hover | background `--bg-overlay-l1`, colour `--text-default` |
| Active | background `--bg-overlay-l1`, colour `--text-default`, weight 500 |
| Status dot | 6px circle; `--text-tertiary` default, `--status-success-default` when active |

Reset `appearance: none` and `outline: none` explicitly - Safari otherwise draws a native button chrome.

### Page Top Nav - `.page-topnav`

`flex`, space-between, padding `16px 20px 0`. The title variant `.page-topnav--title` uses padding `20px 24px 0` and a `heading-sm` title with ellipsis. Actions cluster right with `gap: 8px`.

Text tabs inside the top nav render at 16px / 400, stepping to 500 when active, separated by 24px.

### Breadcrumb - `.mf-breadcrumb`

`flex`, `gap: 8px`, `body-sm`. Links and separators at `--text-tertiary`; links hover to `--text-default`; the current crumb is `--text-default`.

---

## 6. TAGS / CHIPS

### Specs - `.mf-tag`

| Property | Value |
|---|---|
| Height | 20px |
| Padding | `0 8px` |
| Radius | 4px |
| Font | 12px, `line-height: 1`, weight 400 |
| Background | `--bg-overlay-l2` |
| Colour | `--text-default` |
| Border | none |
| Icon | 12px |

### Semantic Variants

| Variant | Background | Colour |
|---|---|---|
| `--brand` | `--bg-brand-popup` `rgba(36,35,35,0.10)` | `--text-default` |
| `--success` | `rgba(32,189,110,0.12)` | `--text-default` |
| `--warning` | `rgba(255,182,65,0.12)` | `--text-default` |
| `--danger` | `rgba(255,49,53,0.12)` | `--text-default` |
| `--info` | `rgba(19,128,237,0.12)` | `--text-default` |
| `--source` | `--bg-overlay-l2` | `--text-secondary`, 11px, height 18px, padding `0 6px` |

**Semantic variants tint the background only. Label text stays `--text-default`.** The two exceptions in the source (`--publish`, `--owner`) colour the label to match the tint and exist for publication ownership signalling only.

No selected state - tags are labels, not controls. If you need a selectable chip, use `.mf-tab--pill`.

---

## 7. OVERLAYS

### Modal / Dialog - `.mf-dialog`

| Part | Spec |
|---|---|
| Container | max-width 520px (`--form` 560px), background `--bg-base-default`, `1px solid --border-neutral-l1`, radius 12px, `overflow: hidden` |
| Shadow | `0 24px 64px @14%, 0 4px 16px @8%` of `--text-default` |
| Head | padding `16px 20px`, space-between, `heading-sm` title, 16px close icon at `--icon-secondary` |
| Body | padding `0 20px 16px`, `body-sm`, `--text-secondary` |
| Foot | padding `12px 20px 24px`, right-aligned, `gap: 8px` |
| Mask | `rgba(0,0,0,0.45)` |

The footer's asymmetric bottom padding (24 vs 12 top) is intentional optical balance. Keep it.

### Dropdown / Menu - `.mf-menu`

| Property | Value |
|---|---|
| Container | `flex column`, `gap: 2px`, background `--bg-menu`, `1px solid --border-neutral-l1`, radius 12px, padding 8px, min-width 180px |
| Shadow | `0 12px 32px @12%, 0 2px 8px @8%` |
| Item | min-height 32px, padding `6px 8px`, radius 8px, `body-sm` |
| Item hover | background `--bg-brand-subtle-hover` `#EDEDED` |
| Selected | weight 500 + a 14px check icon at `margin-left: auto` |
| Divider | 1px `--border-neutral-l1`, `4px 0` margin |
| Group label | padding 8px, `body-xs`, `--text-tertiary`, uppercase |
| Shortcut | `margin-left: auto`, `--text-tertiary` |
| Danger item | `.mf-menu__item--danger` - text and icon `--status-error-default` |
| Submenu | `.mf-menu__item--submenu` positioned `left: 100%`, vertically centred, 2px left offset |

### Popover - `.mf-popover`

Background `--bg-base-default`, `1px solid --border-neutral-l2`, radius 12px, padding 8px, shadow `0 12px 32px @16%`. The `--dark` variant flips to `--bg-tooltip` with white text and `rgba(0,0,0,0.28)` shadow.

### Tooltip - `.mf-tooltip`

`inline-flex`, `gap: 6px`, padding `6px 8px`, background `--bg-tooltip` `#242323`, colour `#FFFFFF`, radius 8px, `body-sm`. Inverted in light mode by design.

---

## 8. STATE PATTERNS

### Empty State - `.mf-empty`

`flex column` centred, padding `40px 24px`, `1px dashed --border-neutral-l1`, radius 12px, colour `--text-tertiary`.
Icon box: 40px square, `1px solid --border-neutral-l1`, radius 8px, `--icon-secondary`, 12px bottom margin.
Title: `body-sm` weight 500 at `--text-default`, 4px bottom margin. Description: `body-sm` at `--text-tertiary`.

### Loading - `.mf-skeleton`

Background `--bg-overlay-l2`, radius 8px, with a `1.6s ease-in-out infinite` gradient sweep using `--bg-overlay-l3`.
Shapes: `--line` 12px tall · `--line-sm` 8px, pill radius · `--title` 18px tall at 50% width · `--circle` 32px · `--circle-sm` 16px.

### Error

Field-level: `.is-error` border plus `body-xs` message at `--status-error-default`.
Block-level: `.mf-alert--danger`.
Never use a red background fill for an error region - tint only.

### Disabled

Foreground `--text-disabled` `#C4C7CC`. Surface either `--bg-brand-disabled` (filled controls) or `--bg-base-secondary` (fields). `cursor: not-allowed`. Geometry unchanged.

---

## 9. TOGGLE / SWITCH

### Specs - `.mf-switch`

| Property | Value |
|---|---|
| Track | 32 × 18px, radius 999px, `1px solid --border-neutral-l1` |
| Thumb | 12px circle, `top: 2px`, `left: 2px`, background `--bg-base-default` |
| Large | `.mf-switch--lg` - 44 × 24px track, 18px thumb, checked `left: 22px` |
| Transition | `150ms` on background, border-color, left |

### States

| State | Track | Thumb |
|---|---|---|
| off | `--bg-overlay-l3` | white at `left: 2px` |
| on | `--status-success-default` `#20BD6E`, border same | `--icon-onbrand` at `left: 16px` |
| disabled | `--bg-overlay-l1`, `cursor: not-allowed` | `--text-disabled` |

> The on-state uses **success**, not brand. This is the one place a status colour carries a non-status meaning, and it is intentional.

---

## 10. CHECKBOX

### Specs - `.mf-checkbox`

| Property | Value |
|---|---|
| Size | 14 × 14px |
| Radius | 2px |
| Border | `1px solid --border-neutral-l2` |
| Background | `--bg-base-default` |

### States

| State | Treatment |
|---|---|
| hover | `border-color: --icon-default` |
| checked | background `--bg-brand`, white 10px check glyph, border `--bg-brand` |
| indeterminate | background `--bg-brand`, white 8px horizontal bar |
| disabled | background `--bg-base-secondary`, border `--border-neutral-l1`, glyph `--text-disabled` |

In tables, `.mf-table--has-checkbox` locks the first column to 40px, `padding: 0`, centred.

---

## 11. RADIO

### Specs - `.mf-radio`

| Property | Value |
|---|---|
| Dot wrapper | 16px circle, `1px solid --border-neutral-l2`, background `--bg-base-default` |
| Checked border | `--bg-brand` |
| Checked inner | 10px circle in `--bg-brand` |

The native input is `display: none`; the visual is `.mf-radio__dot`. Label sits 8px to the right at `body-sm`.

### States

hover → `border-color: --icon-default` · checked → brand border + brand dot · disabled → `--border-neutral-l1` border, `--text-disabled` dot.

---

## 12. SLIDER / RANGE

### Specs - `.mf-slider`

| Part | Spec |
|---|---|
| Track | 4px tall, radius 999px, background `--bg-overlay-l2` |
| Filled track | `--text-default` |
| Thumb | 14px circle, background `--bg-base-default`, `1px solid --border-neutral-l2` |
| Hit area | 20px tall wrapper so the 4px track stays grabbable |

### States

hover → thumb border `--icon-default` · active → thumb border `--bg-brand` · disabled → track `--bg-overlay-l1`, fill `--text-disabled`.

No value bubble, no tick marks unless the data is genuinely discrete.

---

## 13. SELECT / DROPDOWN TRIGGER

### Specs - `.mf-select`

| Property | Value |
|---|---|
| Height | 32px |
| Padding | `0 32px 0 12px` |
| Background | `--bg-base-default` |
| Border | `1px solid --border-neutral-l1` |
| Radius | 8px |
| Appearance | `none` (both prefixed and standard) |
| Font | `body-sm` |
| Chevron | 16px icon, `position: absolute; right: 12px`, `--icon-secondary`, `pointer-events: none` |

Wrap in `.mf-select-wrap` (`position: relative`) so the chevron can be positioned.

### States

focus → `border-color: --border-brand`, `outline: none` · disabled → background `--bg-base-secondary`, colour `--text-disabled`, `opacity: 1` (do not fade - the token already encodes the disabled read).

---

## 14. TEXTAREA

`.mf-textarea` - width 100%, min-height 96px, padding `8px 12px`, background `--bg-base-default`, `1px solid --border-neutral-l1`, radius 8px, `body-sm`, `resize: none`.

### States

focus → `border-color: --border-brand`, `outline: none` · error → `.is-error` border `--status-error-default` · disabled → background `--bg-base-secondary`, colour `--text-disabled`.

Auto-grow textareas cap at a stated max-height and then scroll. The chat composer caps at 336px.

---

## 15. DATA TABLE

### Header Row

| Property | Value |
|---|---|
| Height | 40px |
| Padding | `0 12px` |
| Background | `--bg-base-secondary` |
| Font | 13px, weight 500, `line-height: 1` |
| Colour | `--text-default` |
| Border-bottom | `1px solid --border-neutral-l1` |
| Alignment | left (numeric columns right) |

Filterable headers (`.mf-table__th--filterable`) reveal a 12px filter glyph on hover at `opacity: 0 → 1`; when filtered it stays visible at `--icon-brand`.

### Body Row

| Property | Value |
|---|---|
| Cell padding | `8px 12px` |
| Font | `body-sm` |
| Colour | `--text-default` |
| Divider | `1px solid --border-neutral-l1` on every row, including the last |
| Numeric cells | `.mf-table__num` on the `th` and `td` - right-aligned, mono family, `tabular-nums` |
| Vertical align | middle |
| Min-width | 720px (horizontal scroll below that) |

Member cells combine a 24px avatar with a name (weight 500) and a 12px email at `--text-tertiary`.

### Row States

| State | Treatment |
|---|---|
| hover | `td` background `--bg-base-secondary` |
| selected | checkbox checked; background unchanged |
| status | **inline `.mf-tag` in the status column** |

**Never tint an entire row to convey status.** Action cells are left-aligned, `nowrap`, with `.mf-btn--link` buttons 12px apart.

---

## 16. LAYOUT SHELLS

### App Shell - `.app-shell`

`display: flex; height: 100vh; background: --bg-brand-subtle; gap: 4px;`

The shell background is the app chrome tint `#F6F6F6`. The white content pane floats inside it.

### Main Pane - `.list-main`

`flex: 1; display: flex; flex-direction: column; min-width: 0; background: --bg-base-default; border-radius: 8px; overflow: hidden; margin: 8px 8px 8px 0; height: calc(100vh - 16px);`

### Sidebar - `.mf-aside`

| Part | Spec |
|---|---|
| Container | 240px wide, background `--bg-brand-subtle`, radius 8px, `padding: 0 0 8px` |
| Header | 48px tall, padding `0 8px`, workspace avatar 24px at radius 6px + name (13/500) + unfold chevron |
| Collapse button | 20px square, radius 4px, hover background `--fill-default` |
| Nav | padding `8px 8px 0`, `gap: 4px` |
| Nav item | 32px tall, padding `0 8px`, radius 8px, 13/500, hover and active background `--fill-default` `#E1E3E6` |
| Section label | sticky, `body-xs` at `--text-tertiary`, 16px top margin, actions revealed on hover |
| Session row | 32px tall, padding `0 8px`, radius 8px, `body-sm`; 16px status glyph pinned at `left: 8px`, title indented 22px; meta fades in on hover |
| Body scrollbar | 3px wide, `--fill-default` thumb, transparent track |
| Footer | padding `4px 8px`, settings button 26px tall, credit pill 26px tall at radius 999px with `1px solid --border-neutral-l1` |

---

## 17. CHAT COMPOSER

### Specs - `.mf-chat-input`

| Part | Spec |
|---|---|
| Wrapper | `.mf-chat-input-wrap`, `flex column`, max-width 800px |
| Container | background `--bg-base-default`, `1px solid --border-neutral-l1`, radius 12px, padding 12px, shadow `0 4px 13.7px 6px rgba(21,21,21,0.05)` |
| Textarea | min-height 56px, max-height 336px, transparent, borderless, `body-sm`, `overflow-y: hidden` until capped |
| Toolbar | `flex`, `gap: 4px`, `margin-top: 12px`; left cluster flexes, right cluster is fixed |
| Toolbar icon button | 28px square, radius 8px, `--icon-secondary`; hover background `--bg-overlay-l1` |
| Toolbar text action | 28px tall, padding `0 8px`, radius 8px, `body-sm` at `--text-secondary` |
| Model picker trigger | same as text action, with a 16px chevron at `--icon-tertiary` |
| Send button | 28px square, radius 8px, background `--bg-brand`, icon `--icon-onbrand`; disabled `--bg-brand-disabled` |
| Notice line | centred `body-xs` at `--text-tertiary`, padding `8px 0 4px` |

### Attachments

`.mf-chat-input__attachments` - horizontal scroll, hidden scrollbar, `gap: 8px`, `padding-bottom: 12px`.
Each attachment: 240 × 56px, padding 12px, `1px solid --border-neutral-l1`, radius 8px, white background. 24px type icon, name at 12px, meta at 10px `--text-tertiary`. Remove button is a 20px circle at `top: 4px; right: 4px`, `opacity: 0` until card hover.
Uploading state paints a horizontal progress gradient across the card background via `--upload-progress`.

---

## 18. AVATAR

### Sizes

| Size | Class | Dimension |
|---|---|---|
| sm | `.mf-avatar--sm` | 24px |
| md | `.mf-avatar` | 32px |
| lg | `.mf-avatar--lg` | 36px |

### Specs

`inline-flex` centred, radius 999px, background `--bg-overlay-l3`, colour `--text-default`, `body-sm`, `flex-shrink: 0`. Images fill with `object-fit: cover`.

### Group - `.mf-avatar-group`

20px avatars with `margin-left: -6px` overlap and a `1.5px solid --bg-base-default` separating ring. Overflow count sits 4px right at `body-xs` / `--text-tertiary`.

---

## 19. BADGE / STATUS DOT

Count badge: min-width 18px, height 18px, padding `0 6px`, radius 999px, background `--bg-overlay-l2`, colour `--text-tertiary`, metric font, `tabular-nums`, `display: inline-grid; place-items: center`.

Status dot: 6px circle, radius 999px. `--text-tertiary` inactive · `--status-success-default` running · `--status-warning-default` pending · `--status-error-default` failed.

---

## 20. ALERT / BANNER

### Specs - `.mf-alert`

| Property | Value |
|---|---|
| Display | `flex`, centred, `gap: 8px` |
| Padding | `8px 12px` |
| Background | `--bg-base-secondary` |
| Radius | 8px |
| Font | `body-sm` |
| Icon | 16px, `flex: 0 0 16px` |
| Action | `margin-left: 8px`, `--status-primary-default`, `nowrap` |
| Close | 16px square, transparent, `--icon-tertiary` → `--icon-default` on hover |

Title variant: `.mf-alert__title` at `body-sm-bold`, description at `body-xs` / `--text-secondary`, 2px apart.

### Semantic Variants

| Variant | Background | Icon colour |
|---|---|---|
| `--info` | `#E5F2FF` | `#1380ED` |
| `--success` | `#F0FFF4` | `#20BD6E` |
| `--warning` | `#FFFCF0` | `#FFB641` |
| `--danger` | `#FFF2F0` | `#FF3135` |

**Body copy stays `--text-default` in every variant.** Status is carried by the icon and the tint.

---

## 21. TOAST / NOTIFICATION

### Specs - `.mf-notif`

| Property | Value |
|---|---|
| Display | `flex`, `align-items: flex-start`, `gap: 8px` |
| Max-width | 560px |
| Padding | `8px 12px` |
| Background | `--bg-base-secondary` |
| Border | `1px solid --border-neutral-l1` |
| Radius | 8px |
| Font | `body-sm` |
| Icon | 16px, `margin-top: 2px` |
| Close | 24px square, radius 8px, hover background `--bg-overlay-l2` |
| Actions | `inline-flex`, `gap: 8px`, `margin-top: 8px` |

Container `.mf-toast-container`: `position: fixed; top: 16px; left: 50%; transform: translateX(-50%);` `flex column`, `gap: 8px`, `pointer-events: none` (items re-enable it), `max-width: calc(100vw - 32px)`.

Variants mirror the alert set (`--info`, `--success`, `--warning`, `--alert`, `--danger`) tinting the background and colouring the icon; the border steps to the matching `--status-*-surface-l2`.

Float variant `.mf-notif--float`: white background, hug-content width, `0 4px 16px rgba(0,0,0,0.10), 0 1px 4px rgba(0,0,0,0.06)`.

Animation: `mf-toast-in` / `mf-toast-out`, 200ms ease.

---

## 22. PROGRESS BAR

`.mf-progress` - height 6px, background `--bg-overlay-l2`, radius 999px, `overflow: hidden`.
`.mf-progress__bar` - full height, background `--text-default`, `border-radius: inherit`.
`.mf-progress--brand` swaps the bar to `--bg-brand`.

Semantic fills use `--status-*-default`. No striped or animated fill.

---

## 23. PAGINATION

`.mf-pagination` - `inline-flex`, `gap: 4px`.
`.mf-pagination__item` - min-width 32px, height 32px, padding `0 8px`, transparent background, `--text-secondary`, `1px solid --border-neutral-l1`, radius 8px.
hover → background `--bg-overlay-l2`, colour `--text-default`.
active → background `--bg-overlay-l3`, colour `--text-default`, border `--border-neutral-l2`.
disabled → `opacity: 0.4`, `cursor: not-allowed`.
Range label `.mf-pagination__range` at `body-sm` / `--text-tertiary`.

---

## 24. CODE & KEYBOARD

`.mf-code` - background `--bg-overlay-l1`, `1px solid --border-neutral-l1`, radius 8px, padding `12px 16px`, `code-editor` font, `white-space: pre`, `overflow: auto`.

`.mf-kbd` - height 20px, padding `0 6px`, transparent background, `1px solid --border-neutral-l1`, radius 8px, no shadow, `--text-secondary`. Do not add a 3D keycap shadow.

---

## 25. COMPONENT USAGE RULES

- Compose from `.mf-*` primitives before writing page-local CSS.
- One brand CTA per view.
- Form focus is contrast, not glow.
- Cards use surface tint plus border for elevation. No drop shadows.
- Selected rows, menu items, tabs and pagination use **neutral overlays**, never brand fill.
- Alerts and toasts keep body text neutral; status lives in the icon and tint.
- Tables use row dividers plus inline status tags.
- Big visual blocks are assembled from `.mf-card`, `.mf-tag`, `.mf-avatar`, `.mf-progress`, text styles and 1px rules - never from illustration.
- Charts use the semantic and chart tokens for series, axes, labels, legends and tooltips. No invented chart palettes.
