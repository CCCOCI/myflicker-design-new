# MyFlicker Design 设计资产包

本文件是本资产包的入口。资产包不是可唤醒的 Skill，不会被自动触发，由消费方（其他 Skill / CLI / 人）主动读取。

本文件只包含包信息、消费流程与文件索引，不包含设计规范本身。按需读取，不要一次性加载全部文件。

> **禁止在本文件中使用长破折号（U+2014）**，`scripts/validate.mjs` 会将其判为 ERROR。需要停顿时用逗号、冒号或圆括号。

## 包信息

| 项    | 值                                                              |
| ---- | -------------------------------------------------------------- |
| 包名   | `myflicker-design`                                             |
| 版本   | `1.0.0`                                                        |
| 生成日期 | `2026-09-02`                                                   |
| 品牌领域 | AI agent workspace / 开发者生产力工具                                  |
| 品牌类型 | ui-rich（ui-rich / content-rich）                                |
| 抽取来源 | MyFlicker Figma Kit + 产品实测（迁移自 myflicker-design skill v1.0.10） |
| 主模式  | light（light / dark）                                            |

**版本与元数据的唯一真源是 `myflicker-design-model.yaml` 顶层的 `version` 与 `generated_at` 字段。** 本表是给人看的镜像。每次改动资产包，先改 yaml 顶层版本号，再回填本表并追加 Changelog 条目。两处不一致时 `validate.mjs` 会报 ERROR。

## 消费流程

1. **明确交付物**：页面、组件、设计走查、还是平台实现。
2. **加载唯一真源**：读取 `myflicker-design-model.yaml`，所有视觉决策以此为准，禁止在模型之外臆造 Token。
3. **加载判断依据**：读取 `references/myflicker-philosophy.md`，在做新界面设计或视觉走查前必须加载。
4. **按任务加载规范**：
   - 页面 / 产品 UI → `references/myflicker-tokens.md` + `references/myflicker-components.md`
   - 组件开发 → `references/myflicker-components.md` + 相关 Token 章节
   - HTML/CSS、SwiftUI、Tailwind 实现 → `references/myflicker-platform-mapping.md`
   - 视觉回归对照 → 打开 `previews/` 下对应文件
5. **基于模型构建**：每个颜色、圆角、间距、字号、阴影、动效、组件选择都必须能追溯到 `myflicker-design-model.yaml`。
6. **交付前自检**：眯眼测试 + 检查亮暗双模式、长文本、空状态、密集状态。以 `references/myflicker-philosophy.md` 的反模式清单作为硬性红线。

### 页面原型选择

产出页面前先确定原型，每个原型有固定外壳：

| 原型                        | 外壳                                                                                       | 关键组件                                                   |
| ------------------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------ |
| 落地页 / 营销页                 | 居中列 `max-width 1120px`，`body` 用 `--bg-base-default`（#FFF），**不套灰壳**                       | display 字号、`.mf-btn--primary`、`.mf-card`、`.mf-tag`     |
| 会话页                       | `body` → `--bg-brand-subtle`；`main.main-pane` → 白色 `border-radius:12px`                  | `.mf-chat-input`、消息行、`.mf-code`、`.mf-avatar`           |
| 列表 / 表格页                  | 同上两层外壳                                                                                   | `.mf-table`、`.mf-tabs`、`.mf-input`、`.mf-pagination`    |
| 卡片 / 市场页                  | 同上两层外壳，内容为 `.mf-card-grid`                                                               | `.mf-entity-card`、`.mf-market-card`、`.mf-avatar-group` |
| 设置页                       | 同上两层外壳                                                                                   | `.mf-tabs--pill`、`.mf-switch`、`.mf-select`、`.mf-menu`  |
| 仪表盘 / 工作台 / 知识库 / 任意用户产品页 | `body` → `--bg-brand-subtle`；`main.main-pane--full` → 白色 `border-radius:12px margin:8px` | `.mf-card`、KPI 指标、章节标题                                 |

落地页是唯一豁免两层外壳的原型，其固定结构与最小 CSS 见 `references/myflicker-philosophy.md` 规则 7 及各 `previews/` 对照文件。

## 文件索引

| 文件                                          | 何时读取          | 内容                                       |
| ------------------------------------------- | ------------- | ---------------------------------------- |
| `myflicker-design-model.yaml`               | 始终，第一个        | 机器可读的设计决策唯一真源 + 版本信息                     |
| `myflicker-index.yaml`                      | 资产库入库或快速判断风格时 | 设计风格、哲学、场景分类的人读描述索引                      |
| `references/myflicker-philosophy.md`        | 新建设计或设计走查时    | 设计哲学、7 条构图规则、眯眼测试、16 条反模式                |
| `references/myflicker-tokens.md`            | 样式或布局时        | 字体、色板（亮暗双模式）、间距、圆角、海拔、动效、图标              |
| `references/myflicker-components.md`        | 构建 UI 组件时     | 组件变体、状态、用法、Token 映射，共 25 个章节             |
| `references/myflicker-platform-mapping.md`  | 写代码时          | CSS 变量、React/Tailwind 配置、SwiftUI 映射、字体加载 |
| `previews/myflicker-preview.html`           | 整体视觉参考        | 设计语言总览表达                                 |
| `previews/myflicker-component-library.html` | 组件核对          | 全部组件变体、状态及规格表                            |
| `previews/myflicker-landing-page.html`      | 落地页参考         | 品牌叙事型落地页，唯一不套灰壳的原型                       |
| `previews/myflicker-app-screen.html`        | 产品界面参考        | 高密度真实产品场景表达                              |
| `previews/myflicker-dashboard.html`         | 仪表盘参考         | KPI 指标与工作台布局                             |
| `previews/myflicker-card-page.html`         | 卡片页参考         | 卡片网格与市场页布局                               |
| `previews/myflicker-settings-page.html`     | 设置页参考         | 设置行、开关、分段控件布局                            |
| `previews/myflicker-icon-browser.html`      | 挑图标时          | 266 个图标的可检索浏览器                           |

### 打包资产（本包特有）

本包自带可执行的 CSS 与图标资产，消费方无需自行重写。这是本包相对标准资产包的增量能力。

| 打包资产                              | 内容                                                                                                     |
| --------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `assets/myflicker-tokens.css`     | 全部语义 Token 的 CSS 自定义属性，含亮色与 `[data-theme="dark"]`，以及基础 reset。**第一个加载。**                                |
| `assets/myflicker-components.css` | 可执行的 `.mf-*` 组件层，约 150 个类，覆盖 `references/myflicker-components.md` 全部 25 个章节。依赖 `myflicker-tokens.css`。 |
| `assets/myflicker-icons.js`       | 266 个字形的 MyFlicker 图标集，自注入 sprite。加载后用 `<use href="#mf-{name}">` 引用。                                   |
| `assets/myflicker-icons.css`      | `.mf-icon` 尺寸（12 / 14 / 16 / 20 / 24）与颜色辅助类                                                            |
| `assets/myflicker-icons.json`     | 字形名索引，供查找                                                                                              |
| `assets/myflicker-icons.svg`      | 原始 sprite，供服务端内联的构建流程使用                                                                                |

> 本资产包所有文件名均带品牌 slug 前缀 `myflicker-`，含 `assets/` 内的打包资产，目录名不带。注意区分：**文件名**统一为 `myflicker-` 前缀，**CSS 类名与图标 ID** 仍为 `.mf-*` 与 `#mf-{name}`，两者是不同层级，不要混改。

## 不可违反

- 开始设计或实现前，先声明所需字体及加载方式（见 `references/myflicker-platform-mapping.md`）。本包不加载任何 webfont，使用系统字体栈。
- 禁止直接改 references 里的规范而不先更新 `myflicker-design-model.yaml`。
- 禁止凭通用风格推断本设计语言，必须先读 `references/myflicker-philosophy.md`。
- **禁止在交付文件里写 `<link rel="stylesheet" href="assets/...">` 或 `<script src="assets/...">`。** 相对路径在文件被移动后立即失效，绝对 `file:///` 路径被浏览器跨域策略拦截，把 `assets/` 复制到 HTML 旁边同样禁止（会产生多文件交付物，缺一即坏）。唯一正确做法：完整读取每个资产文件，逐字节粘贴进内联 `<style>` 或 `<script>`，不得摘要、截断或改写。每个交付的 HTML 必须能在磁盘任意位置双击打开，零伴随文件。
- `<head>` 加载顺序固定为：tokens → components → icon 尺寸 → icon sprite → 页面专属 CSS。顺序错会导致组件层引用到未定义的自定义属性。
- 一屏只有一个 `.mf-btn--primary`。
- 所有产品页必须使用两层外壳（灰壳 + 白色圆角面板），落地页除外。

## 保真度说明

**字体**：本包不加载任何 webfont，使用系统字体栈。默认 `PingFang SC`，大号 KPI 数字用 `Inter`，代码与路径用 `JetBrains Mono`。`Inter` 与 `JetBrains Mono` 未安装时回退到系统等宽与无衬线栈，字号与行高规则不变。

**图标**：本包使用 MyFlicker 自有的 266 字形图标集，非替代套件，随 `assets/` 完整打包。禁止混入 Lucide、Phosphor、Tabler、Font Awesome。

**自包含**：本包无 CDN、无 webfont、无 npm 安装依赖，每个产物都能从 `file://` 打开。

**组件来源**：组件在 `myflicker-design-model.yaml` 中标注 `source: observed`（品牌实际拥有，按实测值还原）或 `source: derived`（依据设计原则推导）。走查时以此判断哪些值可追溯、哪些是推导结果。

**兼容性**：CSS 变量方案要求现代浏览器（Chrome / Safari / Firefox 近三年版本）。SwiftUI 映射面向 iOS 15+。Tailwind 配置面向 v3。

## Changelog

### 1.0.0 · 2026-09-02

- 首次以资产包形态发布。前身为可唤醒 Skill `myflicker-design` v1.0.10，本次迁移至标准资产包结构。
- 结构变更：移除 `SKILL.md` 与 `manifest.json`（唤醒契约与技能清单不适用于资产包）；新增 `myflicker-README.md`（入口）与 `myflicker-index.yaml`（检索索引）；原 SKILL.md 的设计哲学、7 条构图规则、眯眼测试、16 条反模式完整迁入新建的 `references/myflicker-philosophy.md`，工作流与页面原型表迁入本 README；全部文档与预览加 `myflicker-` 前缀；8 个预览统一移入 `previews/`。
- 版本元数据收敛：`version` / `generated_at` / `source` 写入 `myflicker-design-model.yaml` 顶层，成为唯一真源。
- 缺陷修复：`--mf-icon-knockout` 在组件库预览中被引用 8 次却从未定义，现补入 `assets/myflicker-tokens.css` 与该预览的 `:root` 及 `[data-theme="dark"]` 两处（亮色 `#FFFFFF`，暗色 `#17181A`）。
- 保留 `assets/`（tokens/components/icons，共 6 个文件）与全部 8 个预览页，含标准 4 页外的 dashboard、card-page、settings-page、icon-browser。`assets/` 内文件由上游 `mf-` 前缀统一改为 `myflicker-` 前缀；CSS 类名 `.mf-*` 与图标 ID `#mf-{name}` 保持不变。
- 视觉零变更：本次不改动任何 Token 值、组件规范正文或预览的视觉表现。
